# Customer Segmentation Project

An interactive Python dashboard that groups customers by demographics and purchasing behavior using **K-Means clustering**.

## Features
- Explore customer age and gender distribution
- Choose clustering features and number of clusters (K)
- Standardize numeric data before clustering
- Visualize customer segments with an interactive scatter plot
- Compare segment profiles, purchase frequency, and average order value
- View marketing recommendations for each segment
- Upload your own customer CSV and download segmented records

## Dataset
`customers.csv` is a generated demonstration dataset. Columns:
- `CustomerID`
- `Gender`
- `Age`
- `Annual_Income_k` (income in thousands)
- `Spending_Score` (1–100)
- `Purchases_Per_Year`
- `Average_Order_Value`

For real business use, replace the sample with customer data you are authorized to use. Remove personal identifiers before sharing data publicly.

## Run on Windows (VS Code / PowerShell)
1. Install Python 3.10 or newer.
2. Extract this project ZIP and open the folder in VS Code.
3. Open Terminal and run:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app.py
```

If PowerShell blocks activation, run `python -m pip install -r requirements.txt` and then `python -m streamlit run app.py`.

The dashboard opens in your browser, usually at `http://localhost:8501`.

## GitHub upload
1. Create a new empty repository on GitHub, for example `customer-segmentation-project`.
2. Open the extracted project folder in VS Code.
3. Run:

```bash
git init
git add .
git commit -m "Add customer segmentation project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/customer-segmentation-project.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username.

## Method
1. Select numeric customer features.
2. Standardize them with `StandardScaler` so large-scale variables do not dominate.
3. Fit `KMeans` with the selected K.
4. Inspect the silhouette score and segment profiles.
5. Interpret each segment and design targeted marketing actions.

## Important
Cluster IDs (0, 1, 2...) are arbitrary labels. The sample data is synthetic and the dashboard is an educational project, not a production customer decision system.
