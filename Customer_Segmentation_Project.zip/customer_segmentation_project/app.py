import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score

st.set_page_config(page_title="Customer Segmentation", page_icon="🛍️", layout="wide")
st.title("🛍️ Customer Segmentation Dashboard")
st.caption("Explore customer behavior, discover segments with K-Means, and turn data into marketing actions.")

@st.cache_data
def load_data(file):
    return pd.read_csv(file)

uploaded = st.sidebar.file_uploader("Upload customer CSV (optional)", type=["csv"])
df = load_data(uploaded) if uploaded else load_data("customers.csv")

required = ["Age", "Annual_Income_k", "Spending_Score"]
missing = [c for c in required if c not in df.columns]
if missing:
    st.error("Your CSV is missing required columns: " + ", ".join(missing))
    st.stop()

st.sidebar.header("Model settings")
features = st.sidebar.multiselect(
    "Features used for clustering",
    options=[c for c in ["Age","Annual_Income_k","Spending_Score","Purchases_Per_Year","Average_Order_Value"] if c in df.columns],
    default=required
)
k = st.sidebar.slider("Number of customer segments (K)", 2, 8, 5)
if len(features) < 2:
    st.warning("Choose at least two numeric features.")
    st.stop()

work = df.copy()
for c in features:
    work[c] = pd.to_numeric(work[c], errors="coerce")
work = work.dropna(subset=features).copy()
scaler = StandardScaler()
X = scaler.fit_transform(work[features])
model = KMeans(n_clusters=k, random_state=42, n_init=10)
work["Segment"] = model.fit_predict(X).astype(str)
score = silhouette_score(X, model.labels_) if len(work) > k else np.nan

c1,c2,c3,c4 = st.columns(4)
c1.metric("Customers analyzed", f"{len(work):,}")
c2.metric("Segments found", k)
c3.metric("Average annual income", f"${work['Annual_Income_k'].mean():.1f}k" if "Annual_Income_k" in work else "—")
c4.metric("Silhouette score", f"{score:.2f}" if np.isfinite(score) else "—")

st.subheader("Customer overview")
left,right = st.columns(2)
with left:
    if "Gender" in work:
        g = work["Gender"].value_counts().rename_axis("Gender").reset_index(name="Customers")
        st.plotly_chart(px.pie(g, names="Gender", values="Customers", title="Customer gender mix", hole=.4), use_container_width=True)
    else:
        st.info("Add a Gender column to view gender mix.")
with right:
    st.plotly_chart(px.histogram(work, x="Age", nbins=20, title="Customer age distribution"), use_container_width=True)

st.subheader("Customer segments")
scatter_x = "Annual_Income_k" if "Annual_Income_k" in features else features[0]
scatter_y = "Spending_Score" if "Spending_Score" in features else features[1]
hover_cols = [c for c in ["CustomerID","Age","Gender","Purchases_Per_Year","Average_Order_Value"] if c in work.columns]
fig = px.scatter(work, x=scatter_x, y=scatter_y, color="Segment", hover_data=hover_cols,
                 title=f"Customer clusters: {scatter_x} vs {scatter_y}", opacity=.8)
st.plotly_chart(fig, use_container_width=True)

profile = work.groupby("Segment")[features].mean().round(1)
profile.insert(0, "Customer_Count", work["Segment"].value_counts().reindex(profile.index).values)
st.subheader("Segment characteristics")
st.dataframe(profile, use_container_width=True)

if "Purchases_Per_Year" in work:
    st.plotly_chart(px.box(work, x="Segment", y="Purchases_Per_Year", color="Segment",
                           title="Purchase frequency by segment"), use_container_width=True)
if "Average_Order_Value" in work:
    st.plotly_chart(px.box(work, x="Segment", y="Average_Order_Value", color="Segment",
                           title="Average order value by segment"), use_container_width=True)

st.subheader("Marketing recommendations")
for seg, row in profile.iterrows():
    spend = row.get("Spending_Score", np.nan)
    income = row.get("Annual_Income_k", np.nan)
    if pd.notna(spend) and spend >= 65:
        advice = "Reward loyal/high-engagement customers with VIP benefits, early access, and personalized offers."
    elif pd.notna(income) and income >= 65 and pd.notna(spend) and spend < 40:
        advice = "Promote premium products with tailored recommendations and value-focused campaigns."
    elif pd.notna(spend) and spend < 35:
        advice = "Use targeted discounts, reminders, and product education to encourage repeat purchases."
    else:
        advice = "Use cross-selling, bundles, and personalized recommendations to increase basket size."
    st.markdown(f"**Segment {seg} ({int(row['Customer_Count'])} customers):** {advice}")

st.subheader("Segmented customer records")
st.dataframe(work, use_container_width=True)
st.download_button("⬇️ Download segmented customers CSV",
                   work.to_csv(index=False).encode("utf-8"),
                   file_name="segmented_customers.csv", mime="text/csv")

with st.expander("About this project"):
    st.write("The app standardizes selected numeric features and applies K-Means clustering. K-Means is an unsupervised learning algorithm: it groups customers with similar measured characteristics. Segment numbers are labels, not rankings.")
    st.write("This project uses a generated sample dataset for demonstration. Replace it with authorized customer data before making business decisions.")
